require('coffee-script');
require('coffee-script/register');
var i2c = require('./lib/i2c');

module.exports = i2c;